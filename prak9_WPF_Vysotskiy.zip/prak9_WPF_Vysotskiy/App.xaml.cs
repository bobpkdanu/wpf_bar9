﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace prak9_WPF_Vysotskiy
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
